#pragma once

double GetFrameTime();
extern double frame_time;