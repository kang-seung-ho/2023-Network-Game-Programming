#include <Windows.h>
#include "obstacle.h"
