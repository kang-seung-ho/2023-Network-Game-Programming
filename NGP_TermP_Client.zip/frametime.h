#pragma once
#include <Windows.h>

double GetFrameTime();
extern double frame_time;