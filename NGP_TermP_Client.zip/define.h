#define POWERUP_ITEM 1
#define SPEEDUP_ITEM 2
#define HEAL_ITEM 3
#define ICE_ITEM 4
#define COIN 5

#define BULLET_SIZE 10
#define ITEM_SIZE 30
#define PLAYER_SIZE 30
#define OBSTACLE_SIZE 30

#define CREATE_ITEM_TIME 3.0

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 1000